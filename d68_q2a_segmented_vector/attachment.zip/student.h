#ifndef __STUDENT_H_
#define __STUDENT_H_

#include "segmented_vector.h"
template <typename T>
CP::SegmentedVector<T>::~SegmentedVector()
{
    // TODO: Write your code here
}
template <typename T>
void CP::SegmentedVector<T>::expand(size_t capacity)
{
    // TODO: Write your code here
}
template <typename T>
void CP::SegmentedVector<T>::insert(int index, const T& element)
{
    // TODO: Write your code here
}
template <typename T>
T& CP::SegmentedVector<T>::operator[](int index) const
{
    // TODO: Write your code here
}
#endif